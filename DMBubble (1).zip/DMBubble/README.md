# 💬 DMBubble — AI-Powered Instagram DM Reply Assistant

A floating bubble overlay for Android that reads your Instagram DMs using AccessibilityService and suggests 3 AI-generated replies in real time.

---

## ✨ Features

- 🫧 **Draggable floating bubble** that lives on top of Instagram
- 🤖 **AI reply suggestions** via OpenAI API (or built-in demo mode — no key needed)
- 🎭 **3 tone options**: Playful 🎉 · Confident 💪 · Curious 🤔
- 📋 **One-tap copy** — tap "Use" to copy a reply and paste it in Instagram
- ♻️ **Regenerate** — get fresh suggestions any time
- 🔒 **Private** — DM text is only sent to the AI API you configure
- 🛑 **Demo mode** — works out-of-the-box with mock suggestions, zero setup required

---

## 📁 Project Structure

```
DMBubble/
├── app/src/main/
│   ├── AndroidManifest.xml              ← Permissions + service declarations
│   ├── java/com/dmbubble/
│   │   ├── MainActivity.kt              ← App entry, permission checks, navigation
│   │   ├── accessibility/
│   │   │   └── DMAccessibilityService.kt ← Reads Instagram DM text nodes
│   │   ├── overlay/
│   │   │   ├── OverlayService.kt        ← Foreground service for floating UI
│   │   │   ├── BubbleIcon.kt            ← The small draggable bubble composable
│   │   │   └── SuggestionPanel.kt       ← Expanded panel with 3 suggestions
│   │   ├── ai/
│   │   │   └── AIService.kt             ← OpenAI Retrofit client + mock mode
│   │   ├── data/
│   │   │   ├── Models.kt                ← Data classes (Settings, Suggestions, etc.)
│   │   │   └── SettingsRepository.kt   ← DataStore persistence
│   │   ├── settings/
│   │   │   └── SettingsScreen.kt        ← API key + tone settings UI
│   │   └── viewmodel/
│   │       └── SettingsViewModel.kt     ← Settings ViewModel
│   └── res/
│       ├── xml/accessibility_service_config.xml
│       └── values/{strings, colors, themes}.xml
├── build.gradle
├── app/build.gradle
└── README.md
```

---

## 🚀 Setup & Build

### Prerequisites

- Android Studio Hedgehog (2023.1.1) or later
- Android SDK 34
- JDK 17+
- A physical Android device or emulator running Android 8.0+ (API 26+)

### Steps

1. **Clone / extract the project**
   ```bash
   cd DMBubble
   ```

2. **Open in Android Studio**
   - File → Open → select the `DMBubble` folder
   - Let Gradle sync complete

3. **Build & Run**
   ```bash
   ./gradlew assembleDebug
   # Or press the Run ▶ button in Android Studio
   ```

4. **Install on device**
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 📱 First-Time Setup on Device

When you open DMBubble for the first time, you'll see a **Setup Checklist** with two steps:

### Step 1: Grant Overlay Permission
1. Tap **"Grant"** next to "Overlay Permission"
2. Find **DMBubble** in the list and toggle it **ON**
3. Press Back to return to the app

### Step 2: Enable Accessibility Service
1. Tap **"Grant"** next to "Accessibility Service"
2. Scroll down to find **"DMBubble DM Reader"**
3. Tap it and toggle **"Use DMBubble DM Reader"** ON
4. Confirm the permission dialog
5. Press Back to return to the app

### Step 3: Start the Service
- Back in DMBubble, tap **"Start DMBubble"**
- A persistent notification confirms the service is active

### Step 4: Open Instagram
- Navigate to any DM conversation
- The **💬 bubble** will appear in the top-right corner
- Tap it to see 3 AI reply suggestions!

---

## 🔑 Adding an API Key (Optional)

Demo mode works without any key. For real AI suggestions:

1. Get an API key from [platform.openai.com](https://platform.openai.com)
2. In DMBubble, go to **Settings** tab
3. Paste your key in the **API Key** field
4. Tap **Save API Key**
5. The status dot turns **green** ✅

The app uses `gpt-3.5-turbo` by default. You can change the model in `AIService.kt`.

---

## 🏗️ Architecture

```
MainActivity
    └── Compose Navigation
         ├── HomeScreen      (permissions + service start/stop)
         └── SettingsScreen  (API key, tone, overlay toggle)

DMAccessibilityService
    └── Monitors Instagram package
    └── Extracts visible text nodes
    └── Sends to OverlayService via Intent

OverlayService (Foreground)
    ├── WindowManager → BubbleIcon (draggable)
    ├── WindowManager → SuggestionPanel (expandable)
    └── Calls AIService on new DM content

AIService
    ├── Retrofit → OpenAI API (real mode)
    └── Mock suggestions (demo mode)

SettingsRepository (DataStore)
    └── API key, tone, overlay enabled
```

---

## 🎛️ Customization

### Change AI Model
In `AIService.kt`, line ~100:
```kotlin
val model: String = "gpt-3.5-turbo",  // Change to "gpt-4" etc.
```

### Change Prompt / Tone
In `AIService.kt`, `buildSystemPrompt()`:
```kotlin
ReplyTone.PLAYFUL -> "Your tone is playful..."
// Edit the instruction string to change personality
```

### Add More Tones
1. Add entry to `ReplyTone` enum in `Models.kt`
2. Add case in `AIService.buildSystemPrompt()`
3. Add case in `AIService.getPlayfulMocks()` etc.
4. The tone selector in `SuggestionPanel.kt` auto-updates

### Support Other Apps (not just Instagram)
In `accessibility_service_config.xml`:
```xml
<!-- Remove packageNames to monitor ALL apps -->
android:packageNames="com.instagram.android,com.whatsapp"
```
In `DMAccessibilityService.kt`, update the `INSTAGRAM_PACKAGE` check.

---

## 🔐 Permissions Explained

| Permission | Why |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Draw the floating bubble over other apps |
| `BIND_ACCESSIBILITY_SERVICE` | Read visible text from Instagram's UI |
| `FOREGROUND_SERVICE` | Keep overlay alive while Instagram is open |
| `INTERNET` | Send DM text to AI API |

**No data is stored permanently.** DM text is sent to your configured AI API only (or not at all in demo mode).

---

## 🐛 Troubleshooting

**Bubble doesn't appear on Instagram**
- Confirm both permissions are granted (green checkmarks in Home screen)
- Make sure the OverlayService is started (tap "Start DMBubble")
- Some Samsung / Xiaomi devices need "Display pop-up windows while running in background" permission too

**Suggestions always show demo mode**
- Add your OpenAI API key in Settings
- Check the key starts with `sk-`

**Accessibility service keeps turning off**
- Some devices (Huawei, Xiaomi) aggressively kill accessibility services
- Go to Battery settings → find DMBubble → disable battery optimization

**Build fails**
- Make sure you have Android SDK 34 installed
- Run `./gradlew clean` then rebuild

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

*Built with Kotlin + Jetpack Compose + AccessibilityService + WindowManager overlay*
