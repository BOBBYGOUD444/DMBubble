package com.dmbubble.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.dmbubble.data.DMConversation
import com.dmbubble.overlay.OverlayService

/**
 * AccessibilityService that monitors Instagram for DM conversations.
 *
 * When Instagram is in the foreground and a DM thread is visible, this service
 * extracts visible message text nodes and broadcasts them to the OverlayService
 * for AI processing.
 *
 * Requires: android.permission.BIND_ACCESSIBILITY_SERVICE + user activation in Settings.
 */
class DMAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "DMAccessibility"
        const val INSTAGRAM_PACKAGE = "com.instagram.android"

        // Broadcast action sent to OverlayService with DM text
        const val ACTION_DM_DETECTED = "com.dmbubble.ACTION_DM_DETECTED"
        const val EXTRA_DM_MESSAGES = "dm_messages"

        // Minimum messages needed before triggering AI
        private const val MIN_MESSAGES_THRESHOLD = 1

        // Throttle: only re-process if content changed
        private var lastExtractedContent = ""
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "DMAccessibilityService connected")
    }

    /**
     * Called whenever an accessibility event fires on Instagram.
     * We look for window content changes and scroll events that suggest
     * the user is actively reading a DM thread.
     */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        val packageName = event.packageName?.toString() ?: return

        // Only process Instagram events
        if (packageName != INSTAGRAM_PACKAGE) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                // Small delay to let UI settle, then extract
                extractDMContent()
            }
        }
    }

    /**
     * Walk the accessibility node tree to find visible DM message text.
     * Instagram DM messages appear as text nodes within a scrollable list.
     */
    private fun extractDMContent() {
        val root = rootInActiveWindow ?: return

        try {
            val messages = mutableListOf<String>()
            collectTextNodes(root, messages)

            if (messages.size < MIN_MESSAGES_THRESHOLD) return

            // Build a fingerprint to avoid re-processing same content
            val contentFingerprint = messages.joinToString("|")
            if (contentFingerprint == lastExtractedContent) return
            lastExtractedContent = contentFingerprint

            Log.d(TAG, "Extracted ${messages.size} message nodes from Instagram DM")

            // Broadcast to OverlayService
            broadcastDMContent(messages)

        } catch (e: Exception) {
            Log.e(TAG, "Error extracting DM content: ${e.message}")
        } finally {
            root.recycle()
        }
    }

    /**
     * Recursively collects text from all visible leaf nodes.
     * Filters out UI chrome (buttons, labels) and keeps only message-like text.
     */
    private fun collectTextNodes(
        node: AccessibilityNodeInfo,
        messages: MutableList<String>,
        depth: Int = 0
    ) {
        if (depth > 20) return  // Prevent deep recursion on complex layouts

        val text = node.text?.toString()?.trim()

        // Include nodes with substantial text (likely message content)
        if (!text.isNullOrBlank() && text.length > 2 && isLikelyMessageText(text)) {
            messages.add(text)
        }

        // Recurse into children
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectTextNodes(child, messages, depth + 1)
            child.recycle()
        }
    }

    /**
     * Heuristic filter: exclude UI elements like timestamps, reaction counts,
     * usernames, and navigation labels. Keep message body text.
     */
    private fun isLikelyMessageText(text: String): Boolean {
        // Skip very short strings (buttons, icons)
        if (text.length < 3) return false

        // Skip common Instagram UI chrome
        val uiStrings = setOf(
            "like", "send", "reply", "react", "more", "active",
            "message", "seen", "delivered", "typing", "dm", "chat",
            "follow", "following", "followers", "story", "reel",
            "photo", "video", "voice", "gif", "audio", "camera"
        )
        if (text.lowercase() in uiStrings) return false

        // Skip pure timestamps (e.g., "2:34 PM", "Yesterday")
        if (text.matches(Regex("\\d{1,2}:\\d{2}\\s*(AM|PM)?"))) return false
        if (text.matches(Regex("\\d+[smhd]"))) return false  // "2m", "5h", etc.

        // Skip single emoji-only strings (reactions)
        if (text.matches(Regex("[\\p{So}\\p{Sc}\\p{Sk}\\p{Sm}]+"))) return false

        return true
    }

    /**
     * Send extracted DM messages to the OverlayService via broadcast.
     * The overlay service will pass these to the AI service for suggestions.
     */
    private fun broadcastDMContent(messages: List<String>) {
        val intent = Intent(ACTION_DM_DETECTED).apply {
            setPackage(packageName)
            putStringArrayListExtra(EXTRA_DM_MESSAGES, ArrayList(messages))
        }
        sendBroadcast(intent)

        // Also start/notify OverlayService directly if it's running
        val serviceIntent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_NEW_DM_CONTENT
            putStringArrayListExtra(EXTRA_DM_MESSAGES, ArrayList(messages))
        }
        startService(serviceIntent)
    }

    override fun onInterrupt() {
        Log.d(TAG, "DMAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "DMAccessibilityService destroyed")
    }
}
