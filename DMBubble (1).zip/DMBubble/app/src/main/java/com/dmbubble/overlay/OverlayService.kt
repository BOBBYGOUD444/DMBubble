package com.dmbubble.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.dmbubble.MainActivity
import com.dmbubble.ai.AIService
import com.dmbubble.data.AppSettings
import com.dmbubble.data.DMConversation
import com.dmbubble.data.ReplyTone
import com.dmbubble.data.ReplySuggestion
import com.dmbubble.data.SettingsRepository
import com.dmbubble.data.SuggestionsResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Foreground service that hosts the floating bubble overlay.
 *
 * Lifecycle:
 * 1. Started from MainActivity when SYSTEM_ALERT_WINDOW permission is granted
 * 2. Receives DM content from AccessibilityService via startService intent
 * 3. Calls AI service, updates overlay UI with suggestions
 * 4. Persists until user stops it from Settings or notification
 */
class OverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    companion object {
        private const val TAG = "OverlayService"
        const val ACTION_NEW_DM_CONTENT = "com.dmbubble.ACTION_NEW_DM_CONTENT"
        const val ACTION_STOP_SERVICE = "com.dmbubble.ACTION_STOP_SERVICE"
        const val EXTRA_DM_MESSAGES = "dm_messages"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "dmbubble_overlay"
    }

    // ─── Lifecycle boilerplate for hosting Compose in a Service ──────────────
    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    // ─── Service components ───────────────────────────────────────────────────
    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var overlayView: View? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var settingsRepository: SettingsRepository
    private val aiService = AIService()

    // ─── Observable UI state ──────────────────────────────────────────────────
    val suggestions = mutableStateOf<List<ReplySuggestion>>(emptyList())
    val isLoading = mutableStateOf(false)
    val isExpanded = mutableStateOf(false)
    val isDemoMode = mutableStateOf(true)
    val currentTone = mutableStateOf(ReplyTone.PLAYFUL)
    val errorMessage = mutableStateOf<String?>(null)
    private var currentConversation: DMConversation = DMConversation(emptyList())
    private var currentSettings: AppSettings = AppSettings()

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settingsRepository = SettingsRepository(this)

        // Load settings
        serviceScope.launch {
            settingsRepository.settingsFlow.collect { settings ->
                currentSettings = settings
                isDemoMode.value = settings.isDemoMode
                currentTone.value = settings.selectedTone
            }
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        showBubble()

        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        Log.d(TAG, "OverlayService created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_NEW_DM_CONTENT -> {
                val messages = intent.getStringArrayListExtra(EXTRA_DM_MESSAGES) ?: return START_STICKY
                currentConversation = DMConversation(messages)
                // Auto-generate suggestions when new DM content arrives
                generateSuggestions()
            }
        }
        return START_STICKY
    }

    /**
     * Shows the small draggable bubble icon on screen.
     * Tapping it expands the full suggestion panel.
     */
    private fun showBubble() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 300
        }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)

            setContent {
                BubbleIcon(
                    isLoading = isLoading.value,
                    hassuggestions = suggestions.value.isNotEmpty(),
                    onClick = { toggleExpanded() }
                )
            }
        }

        // Make bubble draggable
        makeDraggable(composeView, params)

        bubbleView = composeView
        windowManager.addView(composeView, params)
    }

    /**
     * Shows or hides the expanded suggestion panel overlay.
     */
    private fun toggleExpanded() {
        if (isExpanded.value) {
            collapsePanel()
        } else {
            expandPanel()
        }
    }

    private fun expandPanel() {
        isExpanded.value = true

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            dimAmount = 0.4f
        }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)

            setContent {
                SuggestionPanel(
                    suggestions = suggestions.value,
                    isLoading = isLoading.value,
                    isDemoMode = isDemoMode.value,
                    currentTone = currentTone.value,
                    errorMessage = errorMessage.value,
                    onDismiss = { collapsePanel() },
                    onRegenerate = {
                        collapsePanel()
                        generateSuggestions()
                    },
                    onToneChange = { tone ->
                        serviceScope.launch {
                            settingsRepository.saveTone(tone)
                        }
                    }
                )
            }
        }

        overlayView = composeView
        windowManager.addView(composeView, params)
    }

    private fun collapsePanel() {
        isExpanded.value = false
        overlayView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) { }
            overlayView = null
        }
    }

    /**
     * Attach touch listener to make a view draggable within the window.
     */
    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (initialTouchX - event.rawX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }
    }

    /**
     * Call AI service with current conversation, update suggestions state.
     */
    fun generateSuggestions() {
        serviceScope.launch {
            isLoading.value = true
            errorMessage.value = null

            val settings = settingsRepository.settingsFlow.first()

            val result = aiService.generateSuggestions(
                conversation = currentConversation,
                tone = settings.selectedTone,
                apiKey = settings.apiKey
            )

            when (result) {
                is SuggestionsResult.Success -> {
                    suggestions.value = result.suggestions
                    isDemoMode.value = result.suggestions.firstOrNull()?.isDemo == true
                }
                is SuggestionsResult.Error -> {
                    errorMessage.value = result.message
                    // Fall back to mock
                    suggestions.value = aiService.getMockSuggestions(
                        currentConversation, settings.selectedTone
                    )
                }
                else -> {}
            }

            isLoading.value = false
        }
    }

    /** Load demo suggestions immediately (for preview without real DM) */
    fun loadDemoSuggestions() {
        serviceScope.launch {
            val settings = settingsRepository.settingsFlow.first()
            val demo = DMConversation(
                listOf(
                    "hey! what are you up to this weekend? 👀",
                    "thinking of doing something fun",
                    "you should totally come"
                )
            )
            currentConversation = demo
            generateSuggestions()
        }
    }

    // ─── Notification ─────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DMBubble Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the DMBubble floating assistant active"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DMBubble is active")
            .setContentText("Tap the bubble on Instagram to get reply suggestions")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        bubbleView?.let { try { windowManager.removeView(it) } catch (e: Exception) { } }
        overlayView?.let { try { windowManager.removeView(it) } catch (e: Exception) { } }
        serviceScope.cancel()
        super.onDestroy()
        Log.d(TAG, "OverlayService destroyed")
    }
}
