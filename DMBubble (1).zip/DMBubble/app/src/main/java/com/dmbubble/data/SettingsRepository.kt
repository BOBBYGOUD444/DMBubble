package com.dmbubble.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// DataStore singleton extension
val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dmbubble_settings")

/**
 * Repository for persisting app settings using DataStore.
 * All settings are stored as key-value preferences.
 */
class SettingsRepository(private val context: Context) {

    companion object {
        val API_KEY = stringPreferencesKey("api_key")
        val SELECTED_TONE = stringPreferencesKey("selected_tone")
        val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
    }

    /** Flow of current app settings, updates whenever preferences change */
    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val toneStr = prefs[SELECTED_TONE] ?: ReplyTone.PLAYFUL.name
        val tone = try { ReplyTone.valueOf(toneStr) } catch (e: Exception) { ReplyTone.PLAYFUL }
        val apiKey = prefs[API_KEY] ?: ""

        AppSettings(
            apiKey = apiKey,
            selectedTone = tone,
            isDemoMode = apiKey.isBlank(),
            overlayEnabled = prefs[OVERLAY_ENABLED] ?: true
        )
    }

    /** Save API key */
    suspend fun saveApiKey(apiKey: String) {
        context.dataStore.edit { prefs ->
            prefs[API_KEY] = apiKey
        }
    }

    /** Save selected tone */
    suspend fun saveTone(tone: ReplyTone) {
        context.dataStore.edit { prefs ->
            prefs[SELECTED_TONE] = tone.name
        }
    }

    /** Toggle overlay enabled state */
    suspend fun setOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[OVERLAY_ENABLED] = enabled
        }
    }
}
