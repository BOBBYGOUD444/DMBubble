package com.dmbubble

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.dmbubble.overlay.OverlayService
import com.dmbubble.settings.SettingsScreen
import com.dmbubble.viewmodel.SettingsViewModel

// ─── Colors ───────────────────────────────────────────────────────────────────
private val BgDark = Color(0xFF0F0F23)
private val CardDark = Color(0xFF1A1A35)
private val Purple = Color(0xFF6C63FF)
private val Pink = Color(0xFFFF6584)
private val TextWhite = Color(0xFFF0F0F0)
private val TextMuted = Color(0xFF9E9E9E)

/**
 * Main entry point. Handles:
 * - Permission checks (overlay + accessibility)
 * - Navigation between Home and Settings
 * - Starting/stopping the OverlayService
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            DMBubbleApp(activity = this)
        }
    }
}

@Composable
fun DMBubbleApp(activity: ComponentActivity) {
    val navController = rememberNavController()
    val currentRoute by navController.currentBackStackEntryAsState()

    Scaffold(
        containerColor = BgDark,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF12122A),
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = currentRoute?.destination?.route == "home",
                    onClick = { navController.navigate("home") { launchSingleTop = true } },
                    icon = { Text("🫧", fontSize = 20.sp) },
                    label = { Text("Home", color = if (currentRoute?.destination?.route == "home") Purple else TextMuted, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Purple.copy(alpha = 0.15f)
                    )
                )
                NavigationBarItem(
                    selected = currentRoute?.destination?.route == "settings",
                    onClick = { navController.navigate("settings") { launchSingleTop = true } },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null, tint = if (currentRoute?.destination?.route == "settings") Purple else TextMuted) },
                    label = { Text("Settings", color = if (currentRoute?.destination?.route == "settings") Purple else TextMuted, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Purple.copy(alpha = 0.15f)
                    )
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") {
                HomeScreen(activity = activity)
            }
            composable("settings") {
                val vm: SettingsViewModel = viewModel()
                SettingsScreen(viewModel = vm)
            }
        }
    }
}

@Composable
fun HomeScreen(activity: ComponentActivity) {
    var hasOverlayPermission by remember { mutableStateOf(false) }
    var hasAccessibilityPermission by remember { mutableStateOf(false) }
    var serviceRunning by remember { mutableStateOf(false) }

    // Re-check permissions every time screen is visible
    LaunchedEffect(Unit) {
        hasOverlayPermission = Settings.canDrawOverlays(activity)
        hasAccessibilityPermission = isAccessibilityServiceEnabled(activity)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(Modifier.height(16.dp))

        // ── Hero section ───────────────────────────────────────────────────
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Purple, Pink)))
            ) {
                Text("💬", fontSize = 36.sp)
            }

            Text(
                text = "DMBubble",
                color = TextWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Text(
                text = "AI-powered Instagram DM replies\nfloating right where you need them",
                color = TextMuted,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
        }

        // ── Permissions checklist ──────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardDark)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "Setup Checklist",
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            PermissionRow(
                title = "Overlay Permission",
                subtitle = "Float bubble over other apps",
                isGranted = hasOverlayPermission,
                onRequest = {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${activity.packageName}")
                    )
                    activity.startActivity(intent)
                }
            )

            PermissionRow(
                title = "Accessibility Service",
                subtitle = "Read Instagram DM text",
                isGranted = hasAccessibilityPermission,
                onRequest = {
                    activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            )
        }

        // ── Service controls ───────────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardDark)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Overlay Service", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (serviceRunning) "● Service Running" else "○ Service Stopped",
                        color = if (serviceRunning) Color(0xFF00E676) else TextMuted,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = if (serviceRunning) "Bubble active on Instagram" else "Start to show bubble",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }

            // Start button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (!serviceRunning)
                            Brush.linearGradient(listOf(Purple, Pink))
                        else
                            Brush.linearGradient(listOf(Color(0xFF333350), Color(0xFF333350)))
                    )
            ) {
                Button(
                    onClick = {
                        if (!serviceRunning) {
                            if (hasOverlayPermission) {
                                val intent = Intent(activity, OverlayService::class.java)
                                activity.startForegroundService(intent)
                                serviceRunning = true
                            }
                        } else {
                            val intent = Intent(activity, OverlayService::class.java).apply {
                                action = OverlayService.ACTION_STOP_SERVICE
                            }
                            activity.startService(intent)
                            serviceRunning = false
                        }
                    },
                    enabled = hasOverlayPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = if (!serviceRunning) "Start DMBubble" else "Stop Service",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (!hasOverlayPermission) {
                Text(
                    "⚠️ Grant overlay permission first",
                    color = Color(0xFFFFB300),
                    fontSize = 12.sp
                )
            }
        }

        // ── Quick tips ─────────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardDark)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("💡 Quick Tips", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            TipRow("Open Instagram, go to any DM thread")
            TipRow("The 💬 bubble appears at the top-right")
            TipRow("Drag the bubble anywhere on screen")
            TipRow("Tap to expand and see 3 reply options")
            TipRow("Use demo mode with no API key needed")
        }

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PermissionRow(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    onRequest: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (isGranted) Color(0xFF00E676).copy(alpha = 0.15f) else Color(0xFFFF6584).copy(alpha = 0.15f))
            ) {
                Icon(
                    if (isGranted) Icons.Default.Check else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (isGranted) Color(0xFF00E676) else Color(0xFFFF6584),
                    modifier = Modifier.size(16.dp)
                )
            }
            Column {
                Text(title, color = TextWhite, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(subtitle, color = TextMuted, fontSize = 12.sp)
            }
        }
        if (!isGranted) {
            Button(
                onClick = onRequest,
                colors = ButtonDefaults.buttonColors(containerColor = Purple),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Text("Grant", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TipRow(text: String) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("→", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(text, color = TextMuted, fontSize = 13.sp, lineHeight = 18.sp)
    }
}

/** Check if our AccessibilityService is enabled in system settings */
fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
    return enabledServices.any { info ->
        info.resolveInfo.serviceInfo.packageName == context.packageName &&
                info.resolveInfo.serviceInfo.name.contains("DMAccessibilityService")
    }
}
