package com.dmbubble.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dmbubble.data.ReplyTone
import com.dmbubble.data.ReplySuggestion

// Brand colors
private val Purple = Color(0xFF6C63FF)
private val Pink = Color(0xFFFF6584)
private val DarkBg = Color(0xFF1A1A2E)
private val CardBg = Color(0xFF16213E)
private val TextWhite = Color(0xFFF0F0F0)
private val TextMuted = Color(0xFF9E9E9E)

/**
 * The expanded suggestion panel shown when user taps the bubble.
 * Displays 3 AI suggestions with copy/regenerate controls.
 */
@Composable
fun SuggestionPanel(
    suggestions: List<ReplySuggestion>,
    isLoading: Boolean,
    isDemoMode: Boolean,
    currentTone: ReplyTone,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onRegenerate: () -> Unit,
    onToneChange: (ReplyTone) -> Unit
) {
    val context = LocalContext.current

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
        color = DarkBg,
        tonalElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ── Header ─────────────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GradientText(
                        text = "💬 DMBubble",
                        fontSize = 20,
                        fontWeight = FontWeight.Bold
                    )
                    if (isDemoMode) {
                        Spacer(Modifier.width(8.dp))
                        DemoBadge()
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                }
            }

            // ── Tone selector ──────────────────────────────────────────────
            ToneSelector(
                currentTone = currentTone,
                onToneSelected = onToneChange
            )

            // ── Content area ───────────────────────────────────────────────
            if (isLoading) {
                LoadingState()
            } else if (errorMessage != null && suggestions.isEmpty()) {
                ErrorState(message = errorMessage, onRetry = onRegenerate)
            } else {
                // Suggestion cards
                suggestions.forEachIndexed { index, suggestion ->
                    SuggestionCard(
                        suggestion = suggestion,
                        index = index + 1,
                        onCopy = {
                            copyToClipboard(context, suggestion.text)
                        },
                        onUse = {
                            copyToClipboard(context, suggestion.text)
                            Toast.makeText(context, "Copied! Paste in Instagram 📋", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        }
                    )
                }
            }

            // ── Regenerate button ──────────────────────────────────────────
            Button(
                onClick = onRegenerate,
                enabled = !isLoading,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent
                ),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp, Brush.linearGradient(listOf(Purple, Pink))
                )
            ) {
                Icon(
                    Icons.Default.Refresh,
                    contentDescription = null,
                    tint = Purple,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Regenerate",
                    color = Purple,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Demo mode hint
            if (isDemoMode) {
                Text(
                    text = "Add an API key in Settings for real AI suggestions",
                    color = TextMuted,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun SuggestionCard(
    suggestion: ReplySuggestion,
    index: Int,
    onCopy: () -> Unit,
    onUse: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardBg)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(Purple.copy(alpha = 0.3f), Pink.copy(alpha = 0.3f))
                ),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Index badge
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(Purple, Pink))
                        )
                ) {
                    Text(
                        text = "$index",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Action buttons
                Row {
                    // Copy button
                    IconButton(
                        onClick = onCopy,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(Modifier.width(4.dp))
                    // Use button
                    Button(
                        onClick = onUse,
                        modifier = Modifier.height(30.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Purple
                        ),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            horizontal = 12.dp, vertical = 4.dp
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Use", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = suggestion.text,
                color = TextWhite,
                fontSize = 15.sp,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
private fun ToneSelector(
    currentTone: ReplyTone,
    onToneSelected: (ReplyTone) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ReplyTone.entries.forEach { tone ->
            val isSelected = tone == currentTone
            val emoji = when (tone) {
                ReplyTone.PLAYFUL -> "🎉"
                ReplyTone.CONFIDENT -> "💪"
                ReplyTone.CURIOUS -> "🤔"
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        if (isSelected)
                            Brush.linearGradient(listOf(Purple, Pink))
                        else
                            Brush.linearGradient(listOf(CardBg, CardBg))
                    )
                    .border(
                        1.dp,
                        if (isSelected) Color.Transparent else TextMuted.copy(alpha = 0.3f),
                        RoundedCornerShape(10.dp)
                    )
                    .clickable { onToneSelected(tone) }
                    .padding(vertical = 8.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = emoji, fontSize = 16.sp)
                    Text(
                        text = tone.displayName,
                        color = if (isSelected) Color.White else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
private fun LoadingState() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CircularProgressIndicator(
                color = Purple,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = "Crafting replies...",
                color = TextMuted,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun ErrorState(message: String, onRetry: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("⚠️ $message", color = Color(0xFFFF6584), fontSize = 13.sp)
        Button(onClick = onRetry, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
            Text("Try Again")
        }
    }
}

@Composable
private fun DemoBadge() {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Purple.copy(alpha = 0.2f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = "DEMO",
            color = Purple,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun GradientText(text: String, fontSize: Int, fontWeight: FontWeight) {
    Text(
        text = text,
        fontSize = fontSize.sp,
        fontWeight = fontWeight,
        color = TextWhite  // Note: true gradient text requires Canvas; simplified here
    )
}

/** Copy text to Android clipboard and show toast */
private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("DMBubble reply", text))
    Toast.makeText(context, "Copied to clipboard! ✓", Toast.LENGTH_SHORT).show()
}
