package com.dmbubble.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dmbubble.data.AppSettings
import com.dmbubble.data.ReplyTone
import com.dmbubble.data.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel for the Settings screen.
 * Reads and writes settings via DataStore through SettingsRepository.
 */
class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SettingsRepository(application)

    /** Current settings as StateFlow for Compose consumption */
    val settings: StateFlow<AppSettings> = repository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettings()
        )

    fun saveApiKey(apiKey: String) {
        viewModelScope.launch {
            repository.saveApiKey(apiKey.trim())
        }
    }

    fun saveTone(tone: ReplyTone) {
        viewModelScope.launch {
            repository.saveTone(tone)
        }
    }

    fun setOverlayEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setOverlayEnabled(enabled)
        }
    }
}
