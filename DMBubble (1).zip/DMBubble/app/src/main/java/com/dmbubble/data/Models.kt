package com.dmbubble.data

/**
 * Tone options for AI reply generation
 */
enum class ReplyTone(val displayName: String, val description: String) {
    PLAYFUL("Playful", "Fun, lighthearted, emoji-friendly"),
    CONFIDENT("Confident", "Direct, assured, strong presence"),
    CURIOUS("Curious", "Inquisitive, engaged, thoughtful")
}

/**
 * App settings stored via DataStore
 */
data class AppSettings(
    val apiKey: String = "",
    val selectedTone: ReplyTone = ReplyTone.PLAYFUL,
    val isDemoMode: Boolean = true,  // True when no API key is set
    val overlayEnabled: Boolean = true
)

/**
 * A single AI-generated reply suggestion
 */
data class ReplySuggestion(
    val id: String,
    val text: String,
    val tone: ReplyTone,
    val isDemo: Boolean = false
)

/**
 * Result from AI service - either success with suggestions or error
 */
sealed class SuggestionsResult {
    data class Success(val suggestions: List<ReplySuggestion>) : SuggestionsResult()
    data class Error(val message: String) : SuggestionsResult()
    object Loading : SuggestionsResult()
}

/**
 * Represents a captured DM conversation snippet
 */
data class DMConversation(
    val messages: List<String>,
    val appPackage: String = "com.instagram.android"
) {
    fun toPromptText(): String {
        return if (messages.isEmpty()) {
            "Someone just opened a DM with no visible messages yet."
        } else {
            messages.takeLast(6).joinToString("\n")
        }
    }
}
