package com.dmbubble.ai

import com.dmbubble.data.DMConversation
import com.dmbubble.data.ReplyTone
import com.dmbubble.data.ReplySuggestion
import com.dmbubble.data.SuggestionsResult
import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.UUID
import java.util.concurrent.TimeUnit

// ─── Retrofit API Interface ───────────────────────────────────────────────────

/** OpenAI-compatible chat completions endpoint */
interface OpenAIApiService {
    @POST("v1/chat/completions")
    suspend fun getChatCompletions(
        @Header("Authorization") authHeader: String,
        @Body request: ChatRequest
    ): Response<ChatResponse>
}

// ─── Request / Response Models ────────────────────────────────────────────────

data class ChatRequest(
    val model: String = "gpt-3.5-turbo",
    val messages: List<ChatMessage>,
    @SerializedName("max_tokens") val maxTokens: Int = 300,
    val temperature: Double = 0.8,
    val n: Int = 1
)

data class ChatMessage(
    val role: String,  // "system" | "user" | "assistant"
    val content: String
)

data class ChatResponse(
    val choices: List<ChatChoice>?,
    val error: ApiError?
)

data class ChatChoice(
    val message: ChatMessage?,
    @SerializedName("finish_reason") val finishReason: String?
)

data class ApiError(
    val message: String?,
    val type: String?
)

// ─── AI Service ───────────────────────────────────────────────────────────────

/**
 * Handles all AI API communication.
 * Falls back to mock suggestions if API key is missing or call fails.
 */
class AIService {

    private val retrofit: Retrofit by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl("https://api.openai.com/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private val api: OpenAIApiService by lazy {
        retrofit.create(OpenAIApiService::class.java)
    }

    /**
     * Generate 3 reply suggestions for the given DM conversation.
     * Uses real API if key provided, otherwise returns demo suggestions.
     */
    suspend fun generateSuggestions(
        conversation: DMConversation,
        tone: ReplyTone,
        apiKey: String
    ): SuggestionsResult {
        // Use demo mode if no API key
        if (apiKey.isBlank()) {
            return SuggestionsResult.Success(getMockSuggestions(conversation, tone))
        }

        return try {
            val systemPrompt = buildSystemPrompt(tone)
            val userPrompt = buildUserPrompt(conversation)

            val request = ChatRequest(
                model = "gpt-3.5-turbo",
                messages = listOf(
                    ChatMessage(role = "system", content = systemPrompt),
                    ChatMessage(role = "user", content = userPrompt)
                ),
                maxTokens = 300,
                temperature = 0.85
            )

            val response = api.getChatCompletions(
                authHeader = "Bearer $apiKey",
                request = request
            )

            if (response.isSuccessful) {
                val body = response.body()
                val content = body?.choices?.firstOrNull()?.message?.content
                    ?: return SuggestionsResult.Error("Empty response from AI")

                // Parse the 3 numbered suggestions from the response
                val suggestions = parseSuggestions(content, tone)
                SuggestionsResult.Success(suggestions)
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                // Fall back to mock on API error
                SuggestionsResult.Success(getMockSuggestions(conversation, tone))
            }
        } catch (e: Exception) {
            // Network error - fall back to mock suggestions
            SuggestionsResult.Success(getMockSuggestions(conversation, tone))
        }
    }

    /** Build the system prompt based on chosen tone */
    private fun buildSystemPrompt(tone: ReplyTone): String {
        val toneInstruction = when (tone) {
            ReplyTone.PLAYFUL -> "Your tone is playful, fun, and warm — use occasional emojis, keep it light and friendly."
            ReplyTone.CONFIDENT -> "Your tone is confident, direct, and assured — short punchy replies that show presence."
            ReplyTone.CURIOUS -> "Your tone is curious, thoughtful, and engaged — ask follow-up questions naturally."
        }

        return """You generate short Instagram DM reply suggestions. 
$toneInstruction
Generate exactly 3 reply options, each on its own numbered line (1. 2. 3.).
Each reply must be under 20 words. No labels, no explanations — just the 3 replies.
Make them feel natural, like a real person typed them."""
    }

    /** Build the user prompt from the DM conversation */
    private fun buildUserPrompt(conversation: DMConversation): String {
        return """Here's the recent Instagram DM conversation:

${conversation.toPromptText()}

Generate 3 short reply suggestions for the last message."""
    }

    /** Parse numbered suggestions from AI response text */
    private fun parseSuggestions(content: String, tone: ReplyTone): List<ReplySuggestion> {
        val lines = content.trim().lines()
        val suggestions = mutableListOf<ReplySuggestion>()

        for (line in lines) {
            val cleaned = line.trim()
                .removePrefix("1.").removePrefix("2.").removePrefix("3.")
                .removePrefix("1)").removePrefix("2)").removePrefix("3)")
                .trim()

            if (cleaned.isNotBlank() && cleaned.length > 2) {
                suggestions.add(
                    ReplySuggestion(
                        id = UUID.randomUUID().toString(),
                        text = cleaned,
                        tone = tone,
                        isDemo = false
                    )
                )
                if (suggestions.size >= 3) break
            }
        }

        // Pad with mock suggestions if parsing failed
        while (suggestions.size < 3) {
            val mock = getMockSuggestions(DMConversation(emptyList()), tone)
            suggestions.add(mock[suggestions.size])
        }

        return suggestions.take(3)
    }

    // ─── Mock / Demo Suggestions ──────────────────────────────────────────────

    /**
     * Demo mode suggestions — used when no API key is configured.
     * Contextually varies based on conversation content.
     */
    fun getMockSuggestions(conversation: DMConversation, tone: ReplyTone): List<ReplySuggestion> {
        val lastMessage = conversation.messages.lastOrNull()?.lowercase() ?: ""

        val sets = when (tone) {
            ReplyTone.PLAYFUL -> getPlayfulMocks(lastMessage)
            ReplyTone.CONFIDENT -> getConfidentMocks(lastMessage)
            ReplyTone.CURIOUS -> getCuriousMocks(lastMessage)
        }

        return sets.mapIndexed { i, text ->
            ReplySuggestion(
                id = "demo_${tone.name}_$i",
                text = text,
                tone = tone,
                isDemo = true
            )
        }
    }

    private fun getPlayfulMocks(context: String): List<String> {
        return if (context.contains("how") || context.contains("what")) {
            listOf("haha honestly same 😂", "omg wait tell me more!", "ok but that's kinda wild ngl 👀")
        } else if (context.contains("?")) {
            listOf("lol yes absolutely 😄", "haha maybe... depends 👀", "ok fine you got me 😂")
        } else {
            listOf("haha no way!! 😂", "ok but same energy fr 👏", "I'm screaming this is too good 😭")
        }
    }

    private fun getConfidentMocks(context: String): List<String> {
        return if (context.contains("?")) {
            listOf("Definitely.", "100%. No question.", "Always.")
        } else {
            listOf("Noted. Let's talk.", "On it.", "Makes sense to me.")
        }
    }

    private fun getCuriousMocks(context: String): List<String> {
        return if (context.contains("?")) {
            listOf("Wait, what made you think that?", "Hmm, interesting — how so?", "Really? Tell me more about that")
        } else {
            listOf("What's the story behind that?", "How did that happen?", "I'd love to hear more about this")
        }
    }
}
