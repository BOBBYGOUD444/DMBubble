package com.dmbubble.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dmbubble.data.ReplyTone
import com.dmbubble.viewmodel.SettingsViewModel

// ─── Colors ───────────────────────────────────────────────────────────────────
private val BgDark = Color(0xFF0F0F23)
private val CardDark = Color(0xFF1A1A35)
private val Purple = Color(0xFF6C63FF)
private val Pink = Color(0xFFFF6584)
private val TextWhite = Color(0xFFF0F0F0)
private val TextMuted = Color(0xFF9E9E9E)

/**
 * Settings screen where users configure their API key, tone, and overlay preferences.
 */
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val settings by viewModel.settings.collectAsState()
    var apiKeyInput by remember(settings.apiKey) { mutableStateOf(settings.apiKey) }
    var showApiKey by remember { mutableStateOf(false) }
    var apiKeySaved by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(Modifier.height(8.dp))

        // ── API Key Section ────────────────────────────────────────────────
        SettingsCard(title = "🔑 AI API Key") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Enter your OpenAI API key to enable real AI suggestions. Leave blank to use demo mode.",
                    color = TextMuted,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )

                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = {
                        apiKeyInput = it
                        apiKeySaved = false
                    },
                    placeholder = { Text("sk-...", color = TextMuted) },
                    label = { Text("API Key", color = TextMuted) },
                    leadingIcon = {
                        Icon(Icons.Default.Key, contentDescription = null, tint = Purple)
                    },
                    trailingIcon = {
                        Row {
                            // Show/hide toggle
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = TextMuted
                                )
                            }
                            // Save indicator
                            if (apiKeySaved) {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = "Saved",
                                    tint = Color(0xFF00E676),
                                    modifier = Modifier.padding(end = 8.dp)
                                )
                            }
                        }
                    },
                    visualTransformation = if (showApiKey) VisualTransformation.None
                    else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = TextMuted.copy(alpha = 0.3f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        cursorColor = Purple
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Save button
                GradientButton(
                    text = if (apiKeySaved) "✓ Saved!" else "Save API Key",
                    onClick = {
                        viewModel.saveApiKey(apiKeyInput)
                        apiKeySaved = true
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                // Demo mode status
                val isDemo = apiKeyInput.isBlank()
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isDemo) Color(0xFFFFB300) else Color(0xFF00E676))
                    )
                    Text(
                        text = if (isDemo) "Demo mode active — mock suggestions" else "AI mode active",
                        color = if (isDemo) Color(0xFFFFB300) else Color(0xFF00E676),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // ── Tone Selection ─────────────────────────────────────────────────
        SettingsCard(title = "🎭 Reply Tone") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Choose how your AI replies should sound",
                    color = TextMuted,
                    fontSize = 13.sp
                )

                ReplyTone.entries.forEach { tone ->
                    ToneOption(
                        tone = tone,
                        isSelected = settings.selectedTone == tone,
                        onSelect = { viewModel.saveTone(tone) }
                    )
                }
            }
        }

        // ── Overlay Settings ───────────────────────────────────────────────
        SettingsCard(title = "🫧 Overlay Settings") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Show Bubble Overlay", color = TextWhite, fontWeight = FontWeight.Medium)
                    Text(
                        "Float over Instagram when active",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
                Switch(
                    checked = settings.overlayEnabled,
                    onCheckedChange = { viewModel.setOverlayEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Purple,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = CardDark
                    )
                )
            }
        }

        // ── How It Works ───────────────────────────────────────────────────
        SettingsCard(title = "ℹ️ How It Works") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HowItWorksStep("1", "Enable Accessibility Service in Android Settings")
                HowItWorksStep("2", "Grant overlay permission when prompted")
                HowItWorksStep("3", "Open Instagram and go to any DM")
                HowItWorksStep("4", "Tap the 💬 bubble that appears")
                HowItWorksStep("5", "Pick a suggestion and tap Use to copy")
            }
        }

        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ToneOption(
    tone: ReplyTone,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val emoji = when (tone) {
        ReplyTone.PLAYFUL -> "🎉"
        ReplyTone.CONFIDENT -> "💪"
        ReplyTone.CURIOUS -> "🤔"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) Purple.copy(alpha = 0.15f) else Color.Transparent)
            .border(
                1.dp,
                if (isSelected) Purple else TextMuted.copy(alpha = 0.2f),
                RoundedCornerShape(12.dp)
            )
            .clickable { onSelect() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(emoji, fontSize = 20.sp)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = tone.displayName,
                color = if (isSelected) Purple else TextWhite,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = tone.description,
                color = TextMuted,
                fontSize = 12.sp
            )
        }
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Purple)
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardDark)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = title,
            color = TextWhite,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        content()
    }
}

@Composable
private fun HowItWorksStep(number: String, text: String) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Purple, Pink)))
        ) {
            Text(number, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Text(text, color = TextMuted, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(Purple, Pink)))
            .clickable { onClick() }
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp
        )
    }
}
